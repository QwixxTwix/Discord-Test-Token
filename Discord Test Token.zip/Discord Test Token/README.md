<h1 align="center">
  Discord Test Token
</h1>

<h2 align="center">
  English
  Discord Test Token shows if the token is working!
  Convenient check for token performance
  Русский 
  Discord Test Token показывает, работает ли токен!
  Удобная проверка на работоспособность токена                         
</h2>

![ui](https://sun9-69.userapi.com/impg/HPg-71cR_FamnkLmP9Jomz-pOg21fYev3VtO8Q/nOC-WqCXC5g.jpg?size=507x218&quality=95&sign=9920c92a9dd7f3582814889fa205dcfb&c_uniq_tag=v7HgTivL0Kq76h8YTzdeU_TbZeT21stzLqZn5k4FV2U&type=album)
  
> Our telegram channel [Click](https://t.me/QwixxTwixx)
